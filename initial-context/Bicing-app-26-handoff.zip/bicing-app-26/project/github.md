repo: javinegre/bicing-2023
branch: master

## Last sync

date: 2026-08-22T23:31:36Z

### Updated in this project

- Recreated the current app UI (map, info bar, filters, detail sheet, settings modal) as `Bicing Current.dc.html`
- Imported all 43 SVG assets from `src/assets` plus `public/logo192.png`
- Captured the dark MUI theme values (gradient, status-bar colors, marker thresholds) into the recreation

## Screen map

| Project screen | Repo files |
| --- | --- |
| Bicing Current.dc.html — app shell | src/App.tsx, src/App.css, index.html, src/themes/theme.dark.ts, src/providers/CustomThemeProvider.tsx |
| Bicing Current.dc.html — map + markers | src/components/Map/Map.tsx, src/components/MapCanvas/MapCanvas.tsx, src/components/Icons/Icons.helpers.ts, src/components/Icons/ResourceIcons.ts, config/mapOptions.ts, config.ts |
| Bicing Current.dc.html — info bar | src/components/InfoBar/InfoBar.tsx, src/components/InfoBar/InfoBar.helpers.ts, src/utils/distance.ts |
| Bicing Current.dc.html — map controls | src/components/MapControls/MapControls.tsx, src/components/MapFilters/MapFilters.tsx, src/components/MapZoom/MapZoom.tsx, src/components/MapGeoLocation/MapGeoLocation.tsx, src/components/MapBookmark/MapBookmark.tsx, src/components/MapHints/MapHints.tsx, src/reusable/CircleButton/CircleButton.tsx, src/components/ResourceSwitch/ResourceSwitch.tsx |
| Bicing Current.dc.html — detail sheet | src/components/DetailCard/DetailCard.tsx, src/components/DetailCard/DetailCard.helpers.ts, src/components/StationDetail/StationDetail.tsx, src/components/StationList/StationList.tsx, src/components/StationListItem/StationListItem.tsx, src/components/StationStatusBar/StationStatusBar.tsx |
| Bicing Current.dc.html — settings modal | src/components/AppModal/AppModal.tsx, src/components/Icons/CustomSvgIcon.tsx |
